/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import React from 'react'; 
function Menu({nick}){ 
    return (
        <>
            Benvingut/da {nick}
        </> 
    ) 
} 
export default Menu;
