/* eslint-disable no-unused-vars */
import React, { Component } from 'react'
import logo from './qx7jYSYm_400x400.jpg';

class Header extends Component {
    render() {
        return(
            <h1><img src={logo} height="50px" /> El teu portal de montanya.</h1>
        )
    }    
}
export default Header